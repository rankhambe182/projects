package update;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateUserServlet")
public class UpdateUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String firstName = request.getParameter("firstName");
        // Add more parameters as needed
        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rohit", "root", "root@12345");

            // Prepare SQL statement for updating user details based on firstname
            String query = "UPDATE register SET email=?, password=? WHERE firstname=?"; // Modify this query according to your database schema
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, password);
            ps.setString(3, firstName);

            // Execute the update query
            int rowsAffected = ps.executeUpdate();

            // Close statement and connection
            ps.close();
            con.close();

            // Check if update was successful
            if (rowsAffected > 0) {
                // If successful, redirect to a success page
                response.sendRedirect("update_success.jsp");
            } else {
                // If not successful, redirect to an error page
                response.sendRedirect("update_error.jsp");
            }
        } catch (ClassNotFoundException | SQLException e) {
            // Redirect to an error page if there's an exception
            e.printStackTrace();
            response.sendRedirect("update_error.jsp");
        }
    }
}
