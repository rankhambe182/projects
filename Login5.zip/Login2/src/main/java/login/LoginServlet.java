//=================Mycode=====================
package login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
//		//	    try {
////	    	 String email = request.getParameter("email");
////	         String password = request.getParameter("password");
////	         UserDao userDao = new UserDao();
////	         User user = userDao.getUserByEmail(email);
////	        PrintWriter out = response.getWriter();
////	        Class.forName("com.mysql.cj.jdbc.Driver");
////	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rohit", "root", "root@12345");
////	        String n = request.getParameter("firstname1");
////	        String p = request.getParameter("password");
////
////	        // Check if the provided credentials are the default admin credentials
////	        if (n.equals("admin") && p.equals("admin@123")) {
////	            // Redirect to admin page
////	            RequestDispatcher rd = request.getRequestDispatcher("admin.jsp");
////	            rd.forward(request, response);
////	        } else {
////	            // Check the database for regular user credentials
////	            PreparedStatement ps = con.prepareStatement("select firstname from register where firstname=? and password=?");
////	            ps.setString(1, n);
////	            ps.setString(2, p);
////	            ResultSet rs = ps.executeQuery();
////
////	            if (rs.next()) {
////	                // Redirect to regular welcome pag
////	            	//HttpSession session = request.getSession();
////	                RequestDispatcher rd = request.getRequestDispatcher("welcome.jsp");
////	                rd.forward(request, response);
////	            } else {
////	                out.println("Login Failed");
////	                out.println("<a href=login.jsp>Try Again !!</a>");
////	            }
////	        }
////	    } catch (ClassNotFoundException e) {
////	        e.printStackTrace();
////	    } catch (SQLException e) {
////	        e.printStackTrace();
////	    }
//	}

	
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//	
//		
//
//		
		try {
			PrintWriter out = response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rohit","root","root@12345");
			String n = request.getParameter("firstname1");
			String p = request.getParameter("password");
//		    String em =request.getParameter("em");
			PreparedStatement ps = con.prepareStatement("select firstname,email from register where firstname=? and password=?");
			ps.setString(1,n);
			ps.setString(2,p);
//		    PreparedStatement ps = con.prepareStatement("select * from register where firstname=?");
//		    ps.setString(1,n);
			ResultSet rs=ps.executeQuery();
			
			if (rs.next()) {
				String em = rs.getString("email");
	        if (n.equals("admin") && p.equals("admin@123")) {
		            // Redirect to admin page  	
		        //	response.sendRedirect("admin.jsp");
	        	RequestDispatcher rd = request.getRequestDispatcher("admin.jsp");
	        	rd.forward(request, response);
		        } else {
		            // Redirect to regular welcome page
		        	request.setAttribute("email", em);
		        	request.setAttribute("password",p);
		        	request.setAttribute("firstName",n);
		            RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
		            rd.forward(request, response);
		         }
		    } else {
		    
		        out.println("Login Failed");
		        out.println("<a href=login.jsp>Try Again !!</a>");
		    }
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		//	System.out.println(""+e.printStackTrace());
	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	
	}
//		
	}

//
